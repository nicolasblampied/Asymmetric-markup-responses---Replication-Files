%% These files serve as an example. Already interpolated series are present in the dataset.
%All these files (main file, functions, etc.) were retrieved from the supplementary data of Jarocinski and
%Karadi (2020) and have then been modified according to the needs of the present
%paper.

% detrending of series is done by cubic splines

%%
Results=[]; %matrix storing results, i.e. smoothed and interpolated series

VoA=[2 2]; %specifies how many monthly indices (from Mdata) correpsond to each quarterly series (maping from Mdata to X thorugh transform)
VoA_x=[2 2]; %specifies correspodence of monthly indices (from X) to quarterly series (maping from X to X_m)

nknots_y=[5 5]; %last entries are for GDP deflator
nknots_x=[5 5];

%Load data
[Qdata,Qtxt] = xlsread('Interpolate_US_GDP&Mu_CD', 'Quarterly');
[Mdata,Mtxt] = xlsread('Interpolate_US_GDP&Mu_CD', 'Monthly');

[Y, X, names]=transform_direct(Qdata, Mdata, VoA, Qtxt, Mtxt); %function that transforms data (e.g. creat elogs, divide by 1000, first-difference...
months=size(X,1);

%compute detrended dat ausing Cubic splines
%we do separately for y and x since they have different column numbers
global Y_m; global Y_q; global X_m;
Y_m=[]; Y_q=[];

for j=3:size(Y,2); %first two columns are Years and Months, so skip them
    [Y_q(:,j-2),Y_m(:,j-2)]=cspline_qm2(Y(:,j),nknots_y(j-2)); %create Y_m and Y_q - matrix of dentrended Y on monthly and quarterly frequency respectively
    Y_ext(:,j-2)=expand(Y(:,j), months);
end

index=0; %refers to the number of quarterly series to which X(:,j) belongs
for j=1:size(X,2)
    if j-sum(VoA_x(1:index))>0
        index=index+1;
        if VoA_x(index)==0
            index=index+1;
        end
    end
    [X_m(:,j)]=cspline(X(:,j),nknots_x(index));
end

global Yreg; global Xreg;
%now detrend the variables as appropriate
[Yreg, Xreg]=detrend_direct(Y, X, Y_m, Y_q, X_m); 
Yreg=Yreg(:,3:end);

global Xreg2;
[Xreg2,b_start]=regressors_direct(Xreg, Y_ext, X); %put regressors together and get starting values (for MLE optimization)

global Y_data; 
Y_data=Y(:,3:end);

%% Optimization to recover KF parameters by MLE, Inteprolation and Smoothing

namevec={'first','second'}; %vector of names of elements of Xreg2 - needed
%in order to loop through its fields (=sets of monthly indicators for
%quarterly series)

global i;
for i=1:size(b_start,2) %loop through Quarterly variables
    i 
    
    global element; %element stores field name for a relevant quart/monthly indices (for reference whe nusing Xreg2)
    element=namevec{i};
    
    b_st=b_start(:,i); %load correct column vector of starting values correpsonding to the given indicator
    b_st = b_st(~any(isnan(b_st),2),:); %delete rows with missing values

    [bmax,f]=solvopt(b_st, 'lkfilt_inv_nonres5');
    
    %Repeat for problematic cases
    if i==6 || i==5 || i==3 %repeat for problematic cases, taking last bmax as a starting value
        [bmax,f]=solvopt(bmax,'lkfilt_inv_nonres5');
    end
    
    %Interpolation and smoothing:
    tmp=interpolation_and_smoothing(bmax);
    
    %Save results (for monthly components)
    Results=[Results tmp];
 
end

Results=[Results];



