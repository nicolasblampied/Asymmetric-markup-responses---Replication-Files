function [Yreg, Xreg]=detrend_direct(Y, X, Y_m, Y_q, X_m)
%function detrends the monthly and quarterly observations by trends
%specified in matrices Y_m, Y_q, X_m. Detrending is performed by dividing
%value of origina lseries by its trend
%Output: Yreg are detrended values of Y at quarterly frequency, X are detrended
%values of indep regressors at monthly frequency

%create matrices of relevant trends
Y_trend=Y_q;
X_trend=NaN(size(X,1), size(X,2));
%first indicator:
X_trend(:,1)=X_m(:,1); 
X_trend(:,2)=X_m(:,2); 
X_trend(:,3)=X_m(:,3);
X_trend(:,4)=X_m(:,4);

%Y_trend and X_trend are now matrices of trends for Y and X respectively

%detrend:
Y_trend=[zeros(size(Y_trend,1),2), Y_trend];
Yreg=Y./Y_trend;
Xreg=X./X_trend;

end